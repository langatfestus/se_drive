function revealGift(element) {
    const message = element.querySelector('.message');
    message.style.display = 'block';
    message.textContent = "Here's how happy I am for you today!";
  }
  